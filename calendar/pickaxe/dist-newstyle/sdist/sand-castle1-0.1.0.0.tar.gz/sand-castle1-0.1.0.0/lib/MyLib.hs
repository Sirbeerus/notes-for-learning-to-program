module MyLib (someFunc) where

import qualified Shelly as S

someFunc :: Sh ()
someFunc = run_ echo "some funk"
