module Main where

import qualified MyLib (someFunc)
import qualified Shelly as S


main :: Sh ()
main = shelly $ do
  run_ "echo" "Hello, Haskell!"
  MyLib.someFunc
