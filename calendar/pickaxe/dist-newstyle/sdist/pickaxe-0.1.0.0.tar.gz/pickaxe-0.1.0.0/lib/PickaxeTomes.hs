{-# LANGUAGE OverloadedStrings #-}

module PickaxeTomes (someFunc) where

import qualified Shelly as S
import qualified Data.Text as T

someFunc :: S.Sh ()
someFunc = S.run_ "curl" ["https://api.cnft.tools/lists/all/new"]


